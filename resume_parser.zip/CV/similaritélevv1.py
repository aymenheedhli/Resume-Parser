import pandas as pd
from pandas import DataFrame
from fuzzywuzzy import process
import csv

save_file = open(r'C:\Users\Dell\Desktop\CV\competences\raw_skillss.csv', 'w')
writer = csv.writer(save_file, lineterminator = '\n')


def parse_csv(path):

with open(path,'r') as f:
    reader = csv.reader(f, delimiter=',')
    for row in reader:
        yield row


if __name__ == "__main__":
## Create lookup dictionary by parsing the products csv
data = {}
for row in parse_csv('names_1.csv'):
    data[row[0]] = row[0]

## For each row in the lookup compute the partial ratio
for row in parse_csv("names_2.csv"):
    #print(process.extract(row,data, limit = 100))
    for found, score, matchrow in process.extract(row, data, limit=100):
        if score >= 60:
            print('%d%% partial match: "%s" with "%s" ' % (score, row, found))
            Digi_Results = [row, score, found]
            writer.writerow(Digi_Results)


save_file.close()


df = pd.read_csv(r'C:\Users\Dell\Desktop\CV\competences\raw_skillss.csv')
str2Match = df.fillna('######').tolist()
                      
                      
name_match,ratio_match=checker(str2Match,strOptions)
df1 = pd.DataFrame()
df1[‘old_names’]=pd.Series(str2Match)
df1[‘correct_names’]=pd.Series(name_match)
df1[‘correct_ratio’]=pd.Series(ratio_match)
df1.to_excel(‘matched_names.xlsx’, engine=’xlsxwriter’)     

d=pd.read_csv(r'C:\Users\Dell\Desktop\CV\competences\raw_skills.csv')
skills = d.values[:]
skills = re.sub(r'[^\w\s]', '', str(skills))
b_tri = list((nltk.everygrams(skills,2,3)))
skills = nltk.word_tokenize(skills.lower())
skills.append("machine learning")
skills.append("nlp")
skills.append("spss")
skills.append("spss modeler")

import csv
f = open(r'C:\Users\Dell\Desktop\CV\competences\raw_skills.csv', "r+")
r = csv.reader(f, delimiter=";")
lignes = list(r)

