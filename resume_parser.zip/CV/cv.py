from facebook_scraper import get_posts

import pandas as pd

posts=get_posts("vermeg", pages=100)



p=pd.DataFrame(posts)


p.to_csv("porshe.csv",index=False)